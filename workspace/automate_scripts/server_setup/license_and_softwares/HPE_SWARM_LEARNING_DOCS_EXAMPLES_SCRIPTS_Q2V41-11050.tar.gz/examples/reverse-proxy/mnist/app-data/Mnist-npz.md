# Download dataset mnist.npz

Following section provides the link to be used for downloading mnist.npz dataset and data notice associated with it. 

Download mnist.npz dataset from https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz

`curl https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz -o mnist.npz`


DATA_NOTICE: 

MNIST datasets is purportedly provided by the respective dataset creators for free use. The MNIST dataset was obtained at yann.lecun.com/exdb/mnist.  These sites also contain the dataset creators’ offer for others to use the datasets and do not impose any relevant restrictions on that use.  Hewlett Packard Enterprise Company (HPE) does not claim any affiliation with the creators or providers of these datasets, does not claim any ownership interest in these datasets or their contents, does not vouch for the legitimacy of these datasets or the terms under which they have been offered, and does not purport to provide any license to the datasets or their contents.  THE USER ACCEPTS THE DATASETS “AS IS”, WITH ANY ERRORS OR DEFECTS.  HPE MAKES NO REPRESENTATION OR WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND WITH RESPECT TO THE DATASETS, AND TO THE EXTENT PERMITTED BY LAW, HPE DISCLAIMS ALL OTHER WARRANTIES.  HPE DOES NOT WARRANT THAT THE AVAILABILITY, OPERATION, OR USE OF THE DATASETS WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT THE DATASETS WILL OPERATE OTHER THAN AS EXPLAINED IN ANY SUPPORTING MATERIAL.  To the extent permitted by applicable laws, HPE is not liable for any direct, indirect, special, or consequential damages or for lost revenues or profits, downtime costs, or loss or damage to data.  HPE is not obligated to provide any support with respect to the datasets.




